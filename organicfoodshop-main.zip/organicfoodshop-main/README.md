# organic food shop
Ecommerce Project Complete Run

http://127.0.0.1:8000/admin/

username: admin

password: admin

****pip install all Command****

pip install asgiref

pip install certifi

pip install chardet

pip install charset-normalizer

pip install defusedxml

pip install diff-match-patch

pip install Django

pip install django-import-export

pip install django-jazzmin

pip install et-xmlfile

pip install idna

pip install MarkupPy

pip install odfpy

pip install openpyxl

pip install Pillow

pip install pycryptodome

pip install pytz

pip install PyYAML

pip install requests

pip install sqlparse

pip install tablib

pip install tzdata

pip install urllib3

pip install xlrd

pip install xlwt

![Screenshot (4)](https://user-images.githubusercontent.com/67895533/214219897-00c479ee-f0f6-41b9-b57d-76dbcd95c635.png)
![Screenshot (5)](https://user-images.githubusercontent.com/67895533/214219915-1e658e2c-a4ac-4224-9b81-9d661546ddab.png)
![Screenshot (6)](https://user-images.githubusercontent.com/67895533/214219920-e8e33a3f-a22e-4d7b-a723-191bd75e2f53.png)

#organicfoodshop #E-commerce #e-commercewebsite #django #djangopeoject #python
